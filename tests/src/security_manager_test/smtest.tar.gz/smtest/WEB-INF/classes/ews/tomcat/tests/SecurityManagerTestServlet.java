package ews.tomcat.tests;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class SecurityManagerTestServlet extends HttpServlet {
   
   //static final long serialVersionUID = -5077300107674067677L;
   
   public void doGet(HttpServletRequest request, HttpServletResponse response)
      throws IOException, ServletException
   {
      
      // security manager will prevent this call to happen therefore server will not be crashed.
      try {
         System.exit(1);
      }
      catch (java.security.AccessControlException e) {
         // intentionally left empty
      }
      
      response.setContentType("text/html");
      PrintWriter out = response.getWriter();
      out.print("pass");
       
   }

}
